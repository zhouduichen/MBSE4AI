"""Replaceable technology adapters."""

