"""Diagram specification builders."""

